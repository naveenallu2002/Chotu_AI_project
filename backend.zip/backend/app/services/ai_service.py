import requests
from app.config import (
    AI_API_KEY,
    AI_BASE_URL,
    AI_HISTORY_LIMIT,
    AI_MODEL,
    AI_PROVIDER,
    AI_TIMEOUT,
    ASSISTANT_NAME,
    ASSISTANT_ROLE,
)


def normalize_history(chat_history: list[dict] | None = None) -> list[dict]:
    if not chat_history:
        return []

    valid_roles = {"user", "assistant"}
    cleaned_history = []
    for message in chat_history:
        role = str(message.get("role", "")).strip().lower()
        content = str(message.get("content", "")).strip()
        if role in valid_roles and content:
            cleaned_history.append({"role": role, "content": content})

    return cleaned_history[-AI_HISTORY_LIMIT:]


def build_messages(
    user_query: str,
    memory_context: dict | None = None,
    chat_history: list[dict] | None = None,
) -> list:
    memory_text = "No saved memory."
    if memory_context:
        parts = []
        if memory_context.get("name"):
            parts.append(f"User name: {memory_context['name']}")
        if memory_context.get("notes"):
            notes = memory_context["notes"][-5:]
            parts.append("Notes: " + "; ".join(notes))
        if parts:
            memory_text = " | ".join(parts)

    system_prompt = (
        f"{ASSISTANT_ROLE} "
        f"Assistant name: {ASSISTANT_NAME}. "
        f"Use this memory if relevant: {memory_text}"
    )

    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(normalize_history(chat_history))
    messages.append({"role": "user", "content": user_query})
    return messages


def get_ai_response(
    user_query: str,
    memory_context: dict | None = None,
    chat_history: list[dict] | None = None,
) -> str:
    messages = build_messages(user_query, memory_context, chat_history)
    response = None

    try:
        if AI_PROVIDER == "ollama":
            url = f"{AI_BASE_URL}/api/chat"
            payload = {
                "model": AI_MODEL,
                "messages": messages,
                "stream": False,
            }
            response = requests.post(url, json=payload, timeout=AI_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            return data["message"]["content"].strip()

        if AI_PROVIDER == "openai":
            if not AI_API_KEY:
                return "AI error: Missing AI_API_KEY for OpenAI-compatible provider."

            url = f"{AI_BASE_URL}/chat/completions"
            payload = {
                "model": AI_MODEL,
                "messages": messages,
            }
            headers = {
                "Authorization": f"Bearer {AI_API_KEY}",
                "Content-Type": "application/json",
            }
            response = requests.post(
                url,
                json=payload,
                headers=headers,
                timeout=AI_TIMEOUT,
            )
            response.raise_for_status()
            data = response.json()
            return data["choices"][0]["message"]["content"].strip()

        return "Unsupported AI provider."

    except requests.HTTPError:
        detail = response.text.strip() if response is not None else "No response body"
        status = response.status_code if response is not None else "unknown"
        return f"AI error: {status} {detail}"

    except requests.ConnectionError:
        if AI_PROVIDER == "ollama":
            return (
                "AI error: Could not connect to Ollama at "
                f"{AI_BASE_URL}. Start Ollama and make sure the model '{AI_MODEL}' is available."
            )
        return f"AI error: Could not connect to AI provider at {AI_BASE_URL}."

    except requests.Timeout:
        if AI_PROVIDER == "ollama":
            return (
                "AI error: Ollama took too long to respond. "
                f"Try again after the model '{AI_MODEL}' finishes loading, or increase AI_TIMEOUT."
            )
        return "AI error: The AI provider took too long to respond."

    except Exception as e:
        return f"AI error: {str(e)}"
