import requests


def get_weather(city: str) -> str:
    if not city:
        return "Please provide a city name."

    try:
        url = f"https://wttr.in/{city}?format=3"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.text.strip()
    except Exception as e:
        return f"Could not fetch weather for {city}. Error: {str(e)}"
