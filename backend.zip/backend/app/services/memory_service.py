import re
from app.config import MEMORY_FILE
from app.utils.file_utils import load_json, save_json


def get_memory() -> dict:
    return load_json(MEMORY_FILE, {})


def save_memory_text(text: str) -> dict:
    memory = get_memory()

    name_match = re.search(r"my name is\s+(.+)", text, flags=re.IGNORECASE)
    if name_match:
        memory["name"] = name_match.group(1).strip()
        save_json(MEMORY_FILE, memory)
        return memory

    notes = memory.get("notes", [])
    notes.append(text)
    memory["notes"] = notes
    save_json(MEMORY_FILE, memory)
    return memory
