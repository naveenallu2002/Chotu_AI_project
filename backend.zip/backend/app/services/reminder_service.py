from app.config import REMINDER_FILE
from app.utils.file_utils import load_json, save_json


def add_reminder(task: str, time: str) -> dict:
    reminders = load_json(REMINDER_FILE, [])
    item = {"task": task, "time": time}
    reminders.append(item)
    save_json(REMINDER_FILE, reminders)
    return item


def list_reminders() -> list:
    return load_json(REMINDER_FILE, [])


def delete_reminder(index: int) -> dict:
    reminders = load_json(REMINDER_FILE, [])

    if index < 0 or index >= len(reminders):
        return {"success": False, "message": "Invalid reminder index"}

    removed = reminders.pop(index)
    save_json(REMINDER_FILE, reminders)
    return {"success": True, "removed": removed}
