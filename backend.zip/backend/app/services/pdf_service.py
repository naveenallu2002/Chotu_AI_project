import os
import fitz
from app.services.ai_service import get_ai_response


def read_pdf_text(path: str) -> str:
    if not os.path.exists(path):
        return "PDF file not found."

    try:
        doc = fitz.open(path)
        pages = [page.get_text() for page in doc]
        doc.close()
        text = "\n".join(pages).strip()

        if not text:
            return "No readable text found in the PDF."

        return text[:8000]
    except Exception as e:
        return f"Error reading PDF: {str(e)}"


def summarize_pdf(path: str) -> str:
    text = read_pdf_text(path)
    if text.startswith("PDF file not found") or text.startswith("Error"):
        return text

    prompt = f"Summarize this PDF in simple bullet points:\n\n{text}"
    return get_ai_response(prompt)
