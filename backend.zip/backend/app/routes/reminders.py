from fastapi import APIRouter
from app.schemas import ReminderCreate
from app.services.reminder_service import add_reminder, list_reminders, delete_reminder

router = APIRouter(prefix="/reminders", tags=["Reminders"])


@router.post("/")
def create_reminder(payload: ReminderCreate):
    item = add_reminder(payload.task, payload.time)
    return {"message": "Reminder added", "item": item}


@router.get("/")
def get_reminders():
    return {"items": list_reminders()}


@router.delete("/{index}")
def remove_reminder(index: int):
    return delete_reminder(index)
