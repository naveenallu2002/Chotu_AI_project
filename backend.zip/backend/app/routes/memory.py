from fastapi import APIRouter
from app.schemas import MemoryCreate, MemoryResponse
from app.services.memory_service import get_memory, save_memory_text

router = APIRouter(prefix="/memory", tags=["Memory"])


@router.get("/", response_model=MemoryResponse)
def read_memory():
    return MemoryResponse(data=get_memory())


@router.post("/", response_model=MemoryResponse)
def create_memory(payload: MemoryCreate):
    data = save_memory_text(payload.text)
    return MemoryResponse(data=data)
