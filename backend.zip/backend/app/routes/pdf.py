import os
from fastapi import APIRouter, UploadFile, File
from app.config import UPLOAD_DIR
from app.schemas import PDFReadResponse, PDFSummaryResponse
from app.services.pdf_service import read_pdf_text, summarize_pdf

router = APIRouter(prefix="/pdf", tags=["PDF"])


@router.post("/read", response_model=PDFReadResponse)
async def upload_and_read_pdf(file: UploadFile = File(...)):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = os.path.join(UPLOAD_DIR, file.filename)

    content = await file.read()
    with open(file_path, "wb") as f:
        f.write(content)

    text = read_pdf_text(file_path)
    return PDFReadResponse(filename=file.filename, text=text)


@router.post("/summarize", response_model=PDFSummaryResponse)
async def upload_and_summarize_pdf(file: UploadFile = File(...)):
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = os.path.join(UPLOAD_DIR, file.filename)

    content = await file.read()
    with open(file_path, "wb") as f:
        f.write(content)

    summary = summarize_pdf(file_path)
    return PDFSummaryResponse(filename=file.filename, summary=summary)
