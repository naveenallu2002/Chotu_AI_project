from fastapi import APIRouter
from app.schemas import ChatRequest, ChatResponse
from app.services.ai_service import get_ai_response
from app.services.memory_service import get_memory

router = APIRouter(prefix="/ai", tags=["AI"])


@router.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest):
    memory = get_memory()
    history = [item.model_dump() for item in payload.history]
    reply = get_ai_response(payload.message, memory, history)
    return ChatResponse(reply=reply)
