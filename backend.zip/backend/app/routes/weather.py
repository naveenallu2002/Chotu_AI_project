from fastapi import APIRouter
from app.schemas import WeatherResponse
from app.services.weather_service import get_weather

router = APIRouter(prefix="/weather", tags=["Weather"])


@router.get("/{city}", response_model=WeatherResponse)
def weather(city: str):
    result = get_weather(city)
    return WeatherResponse(city=city, result=result)
