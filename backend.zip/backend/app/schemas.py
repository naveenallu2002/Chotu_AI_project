from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    message: str
    history: list[ChatMessage] = Field(default_factory=list)


class ChatResponse(BaseModel):
    reply: str


class WeatherResponse(BaseModel):
    city: str
    result: str


class ReminderCreate(BaseModel):
    task: str
    time: str


class ReminderItem(BaseModel):
    task: str
    time: str


class MemoryCreate(BaseModel):
    text: str


class MemoryResponse(BaseModel):
    data: dict


class PDFSummaryResponse(BaseModel):
    filename: str
    summary: str


class PDFReadResponse(BaseModel):
    filename: str
    text: str
