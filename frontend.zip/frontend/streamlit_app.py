import json

import requests
import streamlit as st
import streamlit.components.v1 as components

API_BASE = "http://127.0.0.1:8000"

st.set_page_config(page_title="Chotu AI Assistant", page_icon="🤖", layout="wide")
st.title("🤖 Chotu v4")
st.write("FastAPI + Streamlit full-stack AI assistant")

st.sidebar.header("Backend Settings")
API_BASE = st.sidebar.text_input("API Base URL", value=API_BASE)

if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = []

tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs(
    ["AI Chat", "Weather", "Reminders", "PDF", "Memory", "Voice"]
)

with tab1:
    st.subheader("AI Chat")
    for msg in st.session_state.chat_messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    prompt = st.chat_input("Ask Chotu anything")
    if prompt:
        history = st.session_state.chat_messages[-8:]
        st.session_state.chat_messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)
        with st.chat_message("assistant"):
            try:
                response = requests.post(
                    f"{API_BASE}/ai/chat",
                    json={"message": prompt, "history": history},
                    timeout=240,
                )
                response.raise_for_status()
                reply = response.json()["reply"]
            except Exception as e:
                reply = f"Request failed: {e}"
            st.markdown(reply)
        st.session_state.chat_messages.append({"role": "assistant", "content": reply})

with tab2:
    st.subheader("Weather")
    city = st.text_input("Enter city")
    if st.button("Get Weather"):
        if city.strip():
            try:
                response = requests.get(f"{API_BASE}/weather/{city}", timeout=20)
                response.raise_for_status()
                st.info(response.json()["result"])
            except Exception as e:
                st.error(f"Request failed: {e}")
        else:
            st.warning("Please enter a city name.")

with tab3:
    st.subheader("Reminders")
    task = st.text_input("Task")
    time_text = st.text_input("Time")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("Add Reminder"):
            if task.strip() and time_text.strip():
                try:
                    response = requests.post(
                        f"{API_BASE}/reminders/",
                        json={"task": task, "time": time_text},
                        timeout=20,
                    )
                    response.raise_for_status()
                    st.success(response.json()["message"])
                except Exception as e:
                    st.error(f"Request failed: {e}")
            else:
                st.warning("Please enter both task and time.")

    with col2:
        if st.button("Show Reminders"):
            try:
                response = requests.get(f"{API_BASE}/reminders/", timeout=20)
                response.raise_for_status()
                items = response.json().get("items", [])
                if items:
                    for i, item in enumerate(items):
                        st.write(f"{i+1}. {item['task']} at {item['time']}")
                else:
                    st.info("No reminders found.")
            except Exception as e:
                st.error(f"Request failed: {e}")

with tab4:
    st.subheader("PDF Reader & Summarizer")
    uploaded_file = st.file_uploader("Upload PDF", type=["pdf"])

    if uploaded_file is not None:
        col1, col2 = st.columns(2)

        with col1:
            if st.button("Read PDF"):
                try:
                    files = {"file": (uploaded_file.name, uploaded_file.getvalue(), "application/pdf")}
                    response = requests.post(f"{API_BASE}/pdf/read", files=files, timeout=120)
                    response.raise_for_status()
                    st.text_area("PDF Text", response.json()["text"], height=350)
                except Exception as e:
                    st.error(f"Request failed: {e}")

        with col2:
            if st.button("Summarize PDF"):
                try:
                    files = {"file": (uploaded_file.name, uploaded_file.getvalue(), "application/pdf")}
                    response = requests.post(f"{API_BASE}/pdf/summarize", files=files, timeout=120)
                    response.raise_for_status()
                    st.success(response.json()["summary"])
                except Exception as e:
                    st.error(f"Request failed: {e}")

with tab5:
    st.subheader("Memory")
    memory_text = st.text_input("Remember something")
    col1, col2 = st.columns(2)

    with col1:
        if st.button("Save Memory"):
            if memory_text.strip():
                try:
                    response = requests.post(
                        f"{API_BASE}/memory/",
                        json={"text": memory_text},
                        timeout=20,
                    )
                    response.raise_for_status()
                    st.success("Memory saved")
                    st.json(response.json()["data"])
                except Exception as e:
                    st.error(f"Request failed: {e}")
            else:
                st.warning("Please enter some text.")

    with col2:
        if st.button("Show Memory"):
            try:
                response = requests.get(f"{API_BASE}/memory/", timeout=20)
                response.raise_for_status()
                st.json(response.json()["data"])
            except Exception as e:
                st.error(f"Request failed: {e}")

with tab6:
    st.subheader("Voice Control")
    st.caption(
        "Use Chrome or Edge for browser voice recognition. Say 'Hey Chotu' to wake it, then speak your command."
    )

    voice_widget = f"""
    <div style="font-family: Arial, sans-serif; padding: 16px; border: 1px solid #dcdcdc; border-radius: 14px; background: linear-gradient(135deg, #f7fbff, #eef7f1);">
      <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap;">
        <div>
          <div style="font-size: 20px; font-weight: 700; color: #10324a;">Chotu Voice Mode</div>
          <div style="font-size: 13px; color: #4a6275;">Wake phrase: <strong>Hey Chotu</strong></div>
        </div>
        <button id="toggle-listening" style="background:#10324a; color:white; border:none; border-radius:999px; padding:10px 16px; cursor:pointer;">
          Start Listening
        </button>
      </div>

      <div id="voice-status" style="margin-top:14px; padding:10px 12px; background:white; border-radius:10px; color:#10324a;">
        Idle. Click Start Listening to enable voice mode.
      </div>

      <div style="margin-top:14px;">
        <div style="font-size:12px; color:#5a6b78; margin-bottom:4px;">Heard</div>
        <div id="heard-text" style="min-height:48px; background:white; border-radius:10px; padding:10px 12px; color:#20313f;"></div>
      </div>

      <div style="margin-top:14px;">
        <div style="font-size:12px; color:#5a6b78; margin-bottom:4px;">Chotu Reply</div>
        <div id="reply-text" style="min-height:90px; background:white; border-radius:10px; padding:10px 12px; color:#20313f; white-space:pre-wrap;"></div>
      </div>
    </div>

    <script>
      const apiBase = {json.dumps(API_BASE)};
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const statusEl = document.getElementById("voice-status");
      const heardEl = document.getElementById("heard-text");
      const replyEl = document.getElementById("reply-text");
      const toggleBtn = document.getElementById("toggle-listening");

      let recognition = null;
      let listening = false;
      let wakeArmed = false;
      let sending = false;

      function setStatus(text) {{
        statusEl.textContent = text;
      }}

      function speakReply(text) {{
        if (!("speechSynthesis" in window) || !text) return;
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 1;
        utterance.pitch = 1;
        window.speechSynthesis.speak(utterance);
      }}

      async function sendMessage(message) {{
        if (!message || sending) return;
        sending = true;
        heardEl.textContent = message;
        replyEl.textContent = "";
        setStatus("Thinking...");

        try {{
          const response = await fetch(`${{apiBase}}/ai/chat`, {{
            method: "POST",
            headers: {{ "Content-Type": "application/json" }},
            body: JSON.stringify({{ message, history: [] }})
          }});

          const data = await response.json();
          const reply = data.reply || "No reply returned.";
          replyEl.textContent = reply;
          setStatus("Ready. Say 'Hey Chotu' for the next command.");
          speakReply(reply);
        }} catch (error) {{
          replyEl.textContent = `Request failed: ${{error}}`;
          setStatus("Voice mode is still listening, but the backend request failed.");
        }} finally {{
          sending = false;
          wakeArmed = false;
        }}
      }}

      function handleTranscript(transcript) {{
        const clean = transcript.trim();
        if (!clean) return;

        const lower = clean.toLowerCase();
        const wakePhrase = "hey chotu";

        if (lower.includes(wakePhrase)) {{
          const afterWake = clean.slice(lower.indexOf(wakePhrase) + wakePhrase.length).trim();
          if (afterWake) {{
            setStatus("Wake phrase detected. Sending command...");
            sendMessage(afterWake);
          }} else {{
            wakeArmed = true;
            heardEl.textContent = clean;
            setStatus("Wake phrase detected. I'm ready for your command.");
          }}
          return;
        }}

        if (wakeArmed) {{
          setStatus("Command heard. Sending...");
          sendMessage(clean);
        }}
      }}

      function startListening() {{
        if (!SpeechRecognition) {{
          setStatus("This browser does not support voice recognition. Use Chrome or Edge.");
          return;
        }}

        if (!recognition) {{
          recognition = new SpeechRecognition();
          recognition.continuous = true;
          recognition.interimResults = false;
          recognition.lang = "en-US";

          recognition.onstart = () => {{
            listening = true;
            toggleBtn.textContent = "Stop Listening";
            setStatus("Listening. Say 'Hey Chotu' to wake the assistant.");
          }};

          recognition.onresult = (event) => {{
            for (let i = event.resultIndex; i < event.results.length; i += 1) {{
              if (event.results[i].isFinal) {{
                handleTranscript(event.results[i][0].transcript);
              }}
            }}
          }};

          recognition.onerror = (event) => {{
            setStatus(`Voice recognition error: ${{event.error}}`);
          }};

          recognition.onend = () => {{
            if (listening) {{
              recognition.start();
            }} else {{
              toggleBtn.textContent = "Start Listening";
              setStatus("Idle. Click Start Listening to enable voice mode.");
            }}
          }};
        }}

        recognition.start();
      }}

      function stopListening() {{
        listening = false;
        wakeArmed = false;
        if (recognition) {{
          recognition.stop();
        }}
        window.speechSynthesis?.cancel();
      }}

      toggleBtn.addEventListener("click", () => {{
        if (listening) {{
          stopListening();
        }} else {{
          startListening();
        }}
      }});
    </script>
    """

    components.html(voice_widget, height=380)
